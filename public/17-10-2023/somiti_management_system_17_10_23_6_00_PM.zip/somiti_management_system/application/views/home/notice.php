<?php
    include "inc/header.php";
    include "inc/sidebar.php";
    include "inc/notice_content.php";
    include "inc/footer.php";
