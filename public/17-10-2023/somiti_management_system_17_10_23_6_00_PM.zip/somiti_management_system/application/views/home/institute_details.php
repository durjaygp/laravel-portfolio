<?php
    include "inc/header.php";
    include "inc/sidebar.php";
    include "inc/institute_details_content.php";
    include "inc/footer.php";
