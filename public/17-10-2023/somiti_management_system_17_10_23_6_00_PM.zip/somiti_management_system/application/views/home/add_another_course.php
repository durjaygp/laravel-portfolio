<?php
include "inc/header.php";
//include "inc/sidebar.php";
include "inc/add_another_course.php";
include "inc/footer.php";
