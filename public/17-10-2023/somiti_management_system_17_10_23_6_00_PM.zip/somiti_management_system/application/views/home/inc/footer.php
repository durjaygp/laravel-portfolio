<div class="col">
    <div>
        <style>
            @media print {
                #footer-menu, #footer-credit{
                    display: none!important;
                }
                #footer-credit p{
                    display: none!important;
                }
                #footer{
                    display: none!important;
                }
            }
        </style>
        <div class="footer-artwork" id="footer-artwork">&nbsp;</div>
        <div class="footer-wrapper full-width" id="footer-wrapper">
            <div id="footer-menu">
                <div style="float: left; font-size: .9em;">
                    সাইটটি শেষ হাল-নাগাদ করা হয়েছে:
                    <span style="font-style: italic;">
                <?php
                echo  date("Y-m-d");

                ?>



            </span>
                </div>
            </div>

            <div class="footer-credit" id="footer">
                <p>
                    পরিকল্পনা ও বাস্তবায়নে:
                    <a href="https://ullapara.sirajganj.gov.bd/bn/site/view/employee_list/7-%E0%A6%89%E0%A6%AA%E0%A6%9C%E0%A7%87%E0%A6%B2%E0%A6%BE%20%E0%A6%A8%E0%A6%BF%E0%A6%B0%E0%A7%8D%E0%A6%AC%E0%A6%BE%E0%A6%B9%E0%A7%80%20%E0%A6%85%E0%A6%AB%E0%A6%BF%E0%A6%B8%E0%A6%BE%E0%A6%B0" target="_blank"> মোঃ উজ্জল হোসেন </a>,&nbsp;
                    <a href="https://ullapara.sirajganj.gov.bd/bn/site/view/employee_list/7-%E0%A6%89%E0%A6%AA%E0%A6%9C%E0%A7%87%E0%A6%B2%E0%A6%BE%20%E0%A6%A8%E0%A6%BF%E0%A6%B0%E0%A7%8D%E0%A6%AC%E0%A6%BE%E0%A6%B9%E0%A7%80%20%E0%A6%85%E0%A6%AB%E0%A6%BF%E0%A6%B8%E0%A6%BE%E0%A6%B0" target="_blank">উপজেলা নির্বাহী অফিসার</a>,&nbsp;
                    <a href="https://ullapara.sirajganj.gov.bd/bn/site/view/employee_list/7-%E0%A6%89%E0%A6%AA%E0%A6%9C%E0%A7%87%E0%A6%B2%E0%A6%BE%20%E0%A6%A8%E0%A6%BF%E0%A6%B0%E0%A7%8D%E0%A6%AC%E0%A6%BE%E0%A6%B9%E0%A7%80%20%E0%A6%85%E0%A6%AB%E0%A6%BF%E0%A6%B8%E0%A6%BE%E0%A6%B0" target="_blank">উল্লাপাড়া উপজেলা</a>,&nbsp;
                    <a href="https://ullapara.sirajganj.gov.bd/bn/site/view/employee_list/7-%E0%A6%89%E0%A6%AA%E0%A6%9C%E0%A7%87%E0%A6%B2%E0%A6%BE%20%E0%A6%A8%E0%A6%BF%E0%A6%B0%E0%A7%8D%E0%A6%AC%E0%A6%BE%E0%A6%B9%E0%A7%80%20%E0%A6%85%E0%A6%AB%E0%A6%BF%E0%A6%B8%E0%A6%BE%E0%A6%B0" target="_blank">সিরাজগঞ্জ</a>&nbsp;
                </p>
                <p>
            <span>
			    কারিগরি সহায়তায়:
			    <a href="//a2i.gov.bd" title=""><img style="height: 30px; vertical-align: baseline;" src="<?= base_url();?>uploads/seo-logo.png" alt="a2i"></a>
			</span>
                    <br>
                    <span style="display: none;">
			    সফটওয়্যার তৈরি:
			    <a href="https://seoexpate.com/" title=""><img style="height: 20px; vertical-align: baseline;" src="<?= base_url();?>uploads/seo-logo.png" alt="https://seoexpate.com/"></a>
			</span>
                </p>
            </div>
        </div>                </div>
</div>
</div>
</div>
</main>

<script src="<?= base_url() ?>assets/home_assets/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url() ?>assets/home_assets/js/script.js"></script>


</body>

</html>
