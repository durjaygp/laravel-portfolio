<!-- main content section -->
<div class="row mt-2">
    <!--right side bar -->
    <div class="col-md-3">
        <div class="right-side text-center">
            <img src="<?= base_url() ?>assets/home_assets/images/bkkb_button_bn.png" alt="" class="img-fluid mb-2" />
            <br />
            <img src="<?= base_url() ?>assets/home_assets/images/Bangladesh-Directory.jpg" alt="" class="img-fluid mb-3" />
            <div class="person-box">
                <p>উপজেলা নির্বাহী অফিসার</p>
                <img src="<?= base_url() ?>uploads/upazila-executive-officer.jpg" alt="" class="img-fluid mt-2 " />
                <p class="text-center mt-3">মোঃ উজ্জল হোসেন </p>
            </div>

        </div>
    </div>
