<?php
include "inc/header.php";
include "inc/sidebar.php";
include "inc/trainee_history_con.php";
include "inc/footer.php";
