<?php
include "inc/header.php";
include "inc/sidebar.php";
include "inc/institute_list_content.php";
include "inc/footer.php";
