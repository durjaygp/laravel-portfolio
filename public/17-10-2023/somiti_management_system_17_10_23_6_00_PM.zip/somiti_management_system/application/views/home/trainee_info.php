<?php
include "inc/header.php";
//include "inc/sidebar.php";
include "inc/trainee_info_con.php";
include "inc/footer.php";
