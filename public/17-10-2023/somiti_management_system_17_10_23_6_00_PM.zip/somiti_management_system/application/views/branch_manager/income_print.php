<?php
include "inc/header_links.php";
//include "inc/left_sidebar.php";
//include "inc/top_bar.php";
include "inc/income_print.php";
//include "inc/footer.php";
