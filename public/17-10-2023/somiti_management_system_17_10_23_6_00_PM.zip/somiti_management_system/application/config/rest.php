<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['rest_default_format'] = 'json';
$config['rest_supported_formats'] = ['json', 'xml'];
?>
